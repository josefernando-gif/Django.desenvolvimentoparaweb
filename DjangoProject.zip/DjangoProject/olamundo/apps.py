from django.apps import AppConfig


class OlamundoConfig(AppConfig):
    name = "olamundo"
