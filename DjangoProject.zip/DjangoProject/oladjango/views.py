from django.http import HttpResponse

# Create your views here.

def olamundo(request):
    return  HttpResponse('ola Mundo')