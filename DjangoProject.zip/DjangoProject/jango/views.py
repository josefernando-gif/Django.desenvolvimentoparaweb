from django.http import HttpResponse
from django.shortcuts import render

def olamundo(request):
    return HttpResponse("Olá Mundo!")